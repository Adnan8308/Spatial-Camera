package com.example.dualparallax

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.hardware.camera2.*
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.ImageReader
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Size
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executor
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

/**
 * Captures ONE photo from two physical back cameras at the same time:
 *   A = main camera, center-cropped digitally (~3x)
 *   B = telephoto camera, native (~3x optical)
 * Both are saved as a pair; GalleryActivity blends them into a parallax view.
 */
class MainActivity : Activity() {

    private lateinit var tv: TextureView
    private lateinit var status: TextView
    private lateinit var shutter: Button

    private val camThread = HandlerThread("cam").also { it.start() }
    private val camHandler = Handler(camThread.looper)
    private val ui = Handler(Looper.getMainLooper())
    private val exec = Executor { camHandler.post(it) }

    private var logicalId: String? = null
    private var mainId = ""
    private var teleId = ""
    private var ratio = 3f              // tele focal length / main focal length
    private var sensorOrientation = 90

    private var opening = false
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var mainReader: ImageReader? = null
    private var teleReader: ImageReader? = null
    private var previewSurface: Surface? = null

    @Volatile private var mainJpeg: ByteArray? = null
    @Volatile private var teleJpeg: ByteArray? = null
    @Volatile private var capturing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val w = resources.displayMetrics.widthPixels

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        // Clipping box: the main camera preview is scaled up ~3x inside it (digital 3x preview)
        val box = FrameLayout(this)
        tv = TextureView(this)
        box.addView(tv, FrameLayout.LayoutParams(-1, -1))
        root.addView(box, FrameLayout.LayoutParams(w, w * 4 / 3, Gravity.TOP).apply { topMargin = 180 })
        tv.post {
            tv.pivotX = tv.width / 2f
            tv.pivotY = tv.height / 2f
            tv.scaleX = ratio
            tv.scaleY = ratio
        }

        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
            setPadding(24, 40, 24, 0)
            text = "Starting..."
        }
        root.addView(status, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 80)
        }
        val gallery = Button(this).apply {
            text = "Gallery"
            setOnClickListener { startActivity(Intent(this@MainActivity, GalleryActivity::class.java)) }
        }
        shutter = Button(this).apply {
            text = "CAPTURE"
            isEnabled = false
            setOnClickListener { capture() }
        }
        bar.addView(gallery)
        bar.addView(shutter)
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 1)
        } else {
            startWhenReady()
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startWhenReady()
        else show("Camera permission is required.")
    }

    override fun onPause() {
        closeCamera()
        super.onPause()
    }

    private fun startWhenReady() {
        if (tv.isAvailable) {
            openCamera()
        } else {
            tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) = openCamera()
                override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
                override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
                override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
            }
        }
    }

    private fun show(msg: String) = ui.post { status.text = msg }

    // ---------------------------------------------------------------- camera discovery

    private fun equiv(c: CameraCharacteristics): Float {
        val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: return 0f
        val s = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: return 0f
        return f * 43.27f / hypot(s.width, s.height)
    }

    private fun findCameras(): Boolean {
        val mgr = getSystemService(CameraManager::class.java)
        val sb = StringBuilder("Back cameras found:\n")
        logicalId = null
        for (id in mgr.cameraIdList) {
            val c = mgr.getCameraCharacteristics(id)
            if (c.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_BACK) continue
            val phys = c.physicalCameraIds
            sb.append("  id $id  physical=[${phys.joinToString()}]  ~${"%.0f".format(equiv(c))}mm\n")
            if (phys.size >= 2 && logicalId == null) {
                val list = phys.map { it to equiv(mgr.getCameraCharacteristics(it)) }
                    .filter { it.second > 0f }.sortedBy { it.second }
                for ((pid, e) in list) sb.append("    - physical $pid  ~${"%.0f".format(e)}mm\n")
                val main = list.firstOrNull { it.second >= 20f }
                val tele = if (main == null) null else list
                    .filter { it.first != main.first && it.second / main.second > 2f }
                    .minByOrNull { abs(it.second / main.second - 3f) }
                if (main != null && tele != null) {
                    logicalId = id
                    mainId = main.first
                    teleId = tele.first
                    ratio = tele.second / main.second
                }
            }
        }
        if (logicalId == null) {
            sb.append("\nCould not find a main + 3x telephoto pair behind one logical camera.\n")
            sb.append("Samsung may be hiding the physical cameras from third-party apps.")
            show(sb.toString())
            return false
        }
        sb.append("\nUsing main=$mainId  tele=$teleId  (crop ${"%.2f".format(ratio)}x)")
        show(sb.toString())
        return true
    }

    private fun bestJpeg(c: CameraCharacteristics): Size {
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val all = map.getOutputSizes(ImageFormat.JPEG).toList()
        val fourThree = all.filter {
            abs(it.width * 3 - it.height * 4) < 8 && it.width.toLong() * it.height <= 50_000_000L
        }
        return (if (fourThree.isNotEmpty()) fourThree else all)
            .maxByOrNull { it.width.toLong() * it.height }!!
    }

    private fun previewSizeFor(c: CameraCharacteristics): Size {
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val sizes = map.getOutputSizes(SurfaceTexture::class.java).toList()
        return sizes.filter { abs(it.width * 3 - it.height * 4) < 8 && it.width <= 1920 }
            .maxByOrNull { it.width.toLong() * it.height } ?: sizes.first()
    }

    // ---------------------------------------------------------------- open + session

    @SuppressLint("MissingPermission")
    private fun openCamera() {
        if (opening) return
        opening = true
        try {
            if (!findCameras()) { opening = false; return }
            val mgr = getSystemService(CameraManager::class.java)
            mgr.openCamera(logicalId!!, object : CameraDevice.StateCallback() {
                override fun onOpened(cd: CameraDevice) { device = cd; createSession() }
                override fun onDisconnected(cd: CameraDevice) { cd.close(); device = null }
                override fun onError(cd: CameraDevice, error: Int) {
                    cd.close(); device = null; show("Camera error $error")
                }
            }, camHandler)
        } catch (e: Exception) {
            opening = false
            show("Open failed: ${e.message}")
        }
    }

    private fun createSession() {
        try {
            val mgr = getSystemService(CameraManager::class.java)
            val mc = mgr.getCameraCharacteristics(mainId)
            val tc = mgr.getCameraCharacteristics(teleId)
            sensorOrientation = mc.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90

            val ps = previewSizeFor(mc)
            val ms = bestJpeg(mc)
            val ts = bestJpeg(tc)

            mainReader = ImageReader.newInstance(ms.width, ms.height, ImageFormat.JPEG, 2).apply {
                setOnImageAvailableListener({ r ->
                    val img = r.acquireNextImage() ?: return@setOnImageAvailableListener
                    try {
                        val buf = img.planes[0].buffer
                        val bytes = ByteArray(buf.remaining()); buf.get(bytes)
                        if (capturing) mainJpeg = bytes
                    } finally { img.close() }
                    checkDone()
                }, camHandler)
            }
            teleReader = ImageReader.newInstance(ts.width, ts.height, ImageFormat.JPEG, 2).apply {
                setOnImageAvailableListener({ r ->
                    val img = r.acquireNextImage() ?: return@setOnImageAvailableListener
                    try {
                        val buf = img.planes[0].buffer
                        val bytes = ByteArray(buf.remaining()); buf.get(bytes)
                        if (capturing) teleJpeg = bytes
                    } finally { img.close() }
                    checkDone()
                }, camHandler)
            }

            val st = tv.surfaceTexture!!
            st.setDefaultBufferSize(ps.width, ps.height)
            previewSurface = Surface(st)

            val cfgs = listOf(
                OutputConfiguration(previewSurface!!).also { it.setPhysicalCameraId(mainId) },
                OutputConfiguration(mainReader!!.surface).also { it.setPhysicalCameraId(mainId) },
                OutputConfiguration(teleReader!!.surface).also { it.setPhysicalCameraId(teleId) }
            )
            val sc = SessionConfiguration(
                SessionConfiguration.SESSION_REGULAR, cfgs, exec,
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) {
                        session = s
                        try {
                            val req = device!!.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                                addTarget(previewSurface!!)
                                set(CaptureRequest.CONTROL_AF_MODE,
                                    CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                            }
                            s.setRepeatingRequest(req.build(), null, camHandler)
                            ui.post {
                                tv.scaleX = ratio; tv.scaleY = ratio
                                shutter.isEnabled = true
                            }
                        } catch (e: Exception) { show("Preview failed: ${e.message}") }
                    }
                    override fun onConfigureFailed(s: CameraCaptureSession) {
                        show("Session failed: this phone does not allow main + tele streams together.")
                    }
                })
            device!!.createCaptureSession(sc)
        } catch (e: Exception) {
            show("Session error: ${e.message}")
        }
    }

    // ---------------------------------------------------------------- capture

    private fun capture() {
        val s = session ?: return
        val d = device ?: return
        mainJpeg = null; teleJpeg = null; capturing = true
        shutter.isEnabled = false
        shutter.text = "Saving..."
        try {
            val req = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                addTarget(mainReader!!.surface)
                addTarget(teleReader!!.surface)
                set(CaptureRequest.JPEG_ORIENTATION, 0)   // we rotate ourselves
                set(CaptureRequest.JPEG_QUALITY, 95.toByte())
                set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            }
            s.capture(req.build(), null, camHandler)
        } catch (e: Exception) {
            capturing = false
            show("Capture failed: ${e.message}")
            ui.post { shutter.isEnabled = true; shutter.text = "CAPTURE" }
        }
    }

    @Synchronized
    private fun checkDone() {
        val m = mainJpeg
        val t = teleJpeg
        if (capturing && m != null && t != null) {
            capturing = false
            mainJpeg = null; teleJpeg = null
            Thread { process(m, t) }.start()
        }
    }

    private fun process(mb: ByteArray, tb: ByteArray) {
        try {
            // A: main camera, center crop (1/ratio) = digital zoom, decoded as a region to save memory
            val dec = BitmapRegionDecoder.newInstance(mb, 0, mb.size, false)!!
            val fw = dec.width
            val fh = dec.height
            val cw = (fw / ratio).toInt()
            val ch = (fh / ratio).toInt()
            val rect = Rect((fw - cw) / 2, (fh - ch) / 2, (fw + cw) / 2, (fh + ch) / 2)
            val mainCrop = dec.decodeRegion(rect, BitmapFactory.Options())
            dec.recycle()

            // B: telephoto, full frame
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(tb, 0, tb.size, bounds)
            var sample = 1
            while ((bounds.outWidth / sample).toLong() * (bounds.outHeight / sample) > 16_000_000L) sample *= 2
            val tele = BitmapFactory.decodeByteArray(tb, 0, tb.size,
                BitmapFactory.Options().apply { inSampleSize = sample })

            // same size for both, then rotate upright
            val outW = (min(2000, min(mainCrop.width, tele.width))) / 4 * 4
            val outH = outW * 3 / 4
            val a = upright(Bitmap.createScaledBitmap(mainCrop, outW, outH, true))
            val b = upright(Bitmap.createScaledBitmap(tele, outW, outH, true))

            show("Computing depth map...")
            // depth is computed for the telephoto image (b), using the main crop (a) as the second viewpoint
            val dw = 360
            val dh = dw * b.height / b.width
            val depth = DepthMap.compute(b, a, dw, dh)

            val dir = File(getExternalFilesDir(null), "pairs").apply { mkdirs() }
            val stamp = System.currentTimeMillis().toString()
            FileOutputStream(File(dir, "${stamp}_a.jpg")).use { a.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            FileOutputStream(File(dir, "${stamp}_b.jpg")).use { b.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            FileOutputStream(File(dir, "${stamp}_d.png")).use { depth.compress(Bitmap.CompressFormat.PNG, 100, it) }

            ui.post { Toast.makeText(this, "Saved pair - open Gallery", Toast.LENGTH_SHORT).show() }
        } catch (e: Throwable) {
            show("Processing failed: ${e.message}")
        } finally {
            ui.post { shutter.isEnabled = true; shutter.text = "CAPTURE" }
        }
    }

    private fun upright(src: Bitmap): Bitmap {
        val m = Matrix().apply { postRotate(sensorOrientation.toFloat()) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    private fun closeCamera() {
        try { session?.close() } catch (_: Exception) {}
        try { device?.close() } catch (_: Exception) {}
        try { mainReader?.close() } catch (_: Exception) {}
        try { teleReader?.close() } catch (_: Exception) {}
        try { previewSurface?.release() } catch (_: Exception) {}
        session = null; device = null; mainReader = null; teleReader = null; previewSurface = null
        opening = false
        ui.post { if (::shutter.isInitialized) shutter.isEnabled = false }
    }
}

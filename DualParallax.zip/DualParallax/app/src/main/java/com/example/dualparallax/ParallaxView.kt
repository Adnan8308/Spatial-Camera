package com.example.dualparallax

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator

/**
 * Shows two slightly different viewpoints (A = main crop, B = telephoto) and
 * blends between them. t = 0 -> A, t = 1 -> B.
 * Controlled by: phone tilt (accelerometer), finger drag, or Auto wiggle.
 */
class ParallaxView(ctx: Context) : View(ctx), SensorEventListener {

    private var a: Bitmap? = null
    private var b: Bitmap? = null
    private var t = 0.5f
    private var touching = false
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val dst = RectF()
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private var anim: ValueAnimator? = null

    /** flip this if the tilt direction feels backwards */
    var invertTilt = false

    var auto = false
        set(value) {
            field = value
            anim?.cancel()
            anim = null
            if (value) {
                anim = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 900
                    repeatMode = ValueAnimator.REVERSE
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = AccelerateDecelerateInterpolator()
                    addUpdateListener { t = it.animatedValue as Float; invalidate() }
                    start()
                }
            }
        }

    init { setBackgroundColor(Color.BLACK) }

    fun setImages(first: Bitmap?, second: Bitmap?) {
        a = first; b = second; invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onDetachedFromWindow() {
        sm.unregisterListener(this)
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (auto || touching) return
        val sign = if (invertTilt) 1f else -1f
        val target = (0.5f + sign * e.values[0] / 6f).coerceIn(0f, 1f)
        t += (target - t) * 0.15f      // smooth
        invalidate()
    }

    override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                touching = true
                if (!auto) { t = (ev.x / width).coerceIn(0f, 1f); invalidate() }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> touching = false
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val ba = a ?: return
        val bb = b ?: return
        val scale = minOf(width.toFloat() / ba.width, height.toFloat() / ba.height)
        val w = ba.width * scale
        val h = ba.height * scale
        dst.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
        paint.alpha = 255
        c.drawBitmap(ba, null, dst, paint)
        paint.alpha = (t * 255).toInt().coerceIn(0, 255)
        c.drawBitmap(bb, null, dst, paint)
    }
}

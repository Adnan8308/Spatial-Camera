package com.example.dualparallax

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.sin

private const val AGSL = """
uniform shader img;
uniform shader dep;
uniform float2 origin;
uniform float2 rsize;
uniform float2 tilt;
uniform float strength;
uniform float zoom;
uniform float showDepth;
uniform float invertDepth;

half4 main(float2 fc) {
    float2 uv = (fc - origin) / rsize;
    uv = (uv - 0.5) / zoom + 0.5;
    float2 shift = tilt * strength;
    float2 p = uv;
    float d = 0.5;
    for (int i = 0; i < 8; i++) {
        d = dep.eval(origin + clamp(p, 0.0, 1.0) * rsize).r;
        if (invertDepth > 0.5) { d = 1.0 - d; }
        p = uv + shift * (d - 0.5);
    }
    p = clamp(p, 0.0, 1.0);
    if (showDepth > 0.5) { return half4(d, d, d, 1.0); }
    return img.eval(origin + p * rsize);
}
"""

/**
 * Renders a photo as a depth-displaced 3D scene.
 * Near pixels move more than far pixels as the phone tilts (or a finger drags).
 */
class ParallaxView(ctx: Context) : View(ctx), SensorEventListener {

    private var color: Bitmap? = null
    private var depth: Bitmap? = null
    private var colorShader: BitmapShader? = null
    private var depthShader: BitmapShader? = null
    private val shader = RuntimeShader(AGSL)
    private val paint = Paint()
    private val dst = RectF()
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private var anim: ValueAnimator? = null

    private var tx = 0f
    private var ty = 0f
    private var bx = 0f
    private var bz = 0f
    private var baseInit = false
    private var touching = false

    var strength = 0.06f
        set(v) { field = v; invalidate() }
    var invertTilt = false
        set(v) { field = v; invalidate() }
    var invertDepth = false
        set(v) { field = v; invalidate() }
    var showDepth = false
        set(v) { field = v; invalidate() }

    var auto = false
        set(value) {
            field = value
            anim?.cancel()
            anim = null
            if (value) {
                anim = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
                    duration = 3000
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    addUpdateListener {
                        val a = it.animatedValue as Float
                        tx = cos(a); ty = 0.5f * sin(a); invalidate()
                    }
                    start()
                }
            }
        }

    init { setBackgroundColor(Color.BLACK) }

    fun setImages(c: Bitmap?, d: Bitmap?) {
        color = c
        depth = if (c != null && d != null) Bitmap.createScaledBitmap(d, c.width / 2, c.height / 2, true) else null
        colorShader = c?.let { BitmapShader(it, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
        depthShader = depth?.let { BitmapShader(it, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
        updateMatrices()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        updateMatrices()
    }

    private fun updateMatrices() {
        val c = color ?: return
        val d = depth ?: return
        if (width == 0 || height == 0) return
        val scale = minOf(width.toFloat() / c.width, height.toFloat() / c.height)
        val w = c.width * scale
        val h = c.height * scale
        dst.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
        val mc = Matrix().apply { setRectToRect(RectF(0f, 0f, c.width.toFloat(), c.height.toFloat()), dst, Matrix.ScaleToFit.FILL) }
        val md = Matrix().apply { setRectToRect(RectF(0f, 0f, d.width.toFloat(), d.height.toFloat()), dst, Matrix.ScaleToFit.FILL) }
        colorShader?.setLocalMatrix(mc)
        depthShader?.setLocalMatrix(md)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onDetachedFromWindow() {
        sm.unregisterListener(this)
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (auto || touching) return
        val ax = e.values[0]
        val az = e.values[2]
        if (!baseInit) { bx = ax; bz = az; baseInit = true }
        bx += (ax - bx) * 0.004f      // slowly re-center on how you hold the phone
        bz += (az - bz) * 0.004f
        val targetX = (-(ax - bx) / 4f).coerceIn(-1f, 1f)
        val targetY = ((az - bz) / 4f).coerceIn(-1f, 1f)
        tx += (targetX - tx) * 0.2f
        ty += (targetY - ty) * 0.2f
        invalidate()
    }

    override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                touching = true
                if (!auto) {
                    tx = ((ev.x / width) - 0.5f) * 2f
                    ty = ((ev.y / height) - 0.5f) * 2f
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> touching = false
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val cs = colorShader ?: return
        val ds = depthShader ?: return
        val sign = if (invertTilt) -1f else 1f
        shader.setInputShader("img", cs)
        shader.setInputShader("dep", ds)
        shader.setFloatUniform("origin", dst.left, dst.top)
        shader.setFloatUniform("rsize", dst.width(), dst.height())
        shader.setFloatUniform("tilt", tx * sign, ty * sign)
        shader.setFloatUniform("strength", strength)
        shader.setFloatUniform("zoom", 1f + strength * 1.3f)
        shader.setFloatUniform("showDepth", if (showDepth) 1f else 0f)
        shader.setFloatUniform("invertDepth", if (invertDepth) 1f else 0f)
        paint.shader = shader
        c.drawRect(dst, paint)
    }
}

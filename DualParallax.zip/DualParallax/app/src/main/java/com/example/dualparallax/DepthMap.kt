package com.example.dualparallax

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Simple stereo block matching in pure Kotlin.
 * ref   = image whose pixels get a depth value (we use the telephoto, it is the sharper one)
 * other = the second viewpoint (main camera crop)
 * Returns a grayscale bitmap: white = near, black = far.
 */
object DepthMap {

    private const val D_MIN = -16
    private const val D_MAX = 32

    fun compute(ref: Bitmap, other: Bitmap, w: Int, h: Int): Bitmap {
        val n = w * h
        val tmp = FloatArray(n)
        val ps = FloatArray(max(w, h) + 1)

        val nRef = normalize(gray(ref, w, h), w, h, tmp, ps)
        val nOth = normalize(gray(other, w, h), w, h, tmp, ps)

        val best = FloatArray(n) { Float.MAX_VALUE }
        val bestD = IntArray(n)
        val diff = FloatArray(n)
        val agg = FloatArray(n)

        for (d in D_MIN..D_MAX) {
            for (y in 0 until h) {
                val row = y * w
                for (x in 0 until w) {
                    val xs = x + d
                    diff[row + x] = if (xs in 0 until w) abs(nRef[row + x] - nOth[row + xs]) else 1.5f
                }
            }
            box(diff, agg, tmp, ps, w, h, 5)
            for (i in 0 until n) {
                if (agg[i] < best[i]) { best[i] = agg[i]; bestD[i] = d }
            }
        }

        var disp = FloatArray(n) { bestD[it].toFloat() }
        val out = FloatArray(n)
        repeat(2) {
            box(disp, out, tmp, ps, w, h, 3)
            disp = out.copyOf()
        }

        // near/far heuristic: lower part of a photo is usually closer than the top
        var top = 0f; var bottom = 0f
        val third = h / 3
        for (y in 0 until third) for (x in 0 until w) top += disp[y * w + x]
        for (y in h - third until h) for (x in 0 until w) bottom += disp[y * w + x]
        val invert = bottom < top

        val sorted = disp.copyOf().also { it.sort() }
        val lo = sorted[(n * 0.03f).toInt()]
        val hi = sorted[(n * 0.97f).toInt()]
        val span = max(hi - lo, 1f)

        val px = IntArray(n)
        for (i in 0 until n) {
            var v = ((disp[i] - lo) / span).coerceIn(0f, 1f)
            if (invert) v = 1f - v
            val g = (v * 255f).toInt()
            px[i] = Color.rgb(g, g, g)
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun gray(b: Bitmap, w: Int, h: Int): FloatArray {
        val s = Bitmap.createScaledBitmap(b, w, h, true)
        val px = IntArray(w * h)
        s.getPixels(px, 0, w, 0, 0, w, h)
        if (s !== b) s.recycle()
        return FloatArray(w * h) {
            val p = px[it]
            (0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)) / 255f
        }
    }

    /** remove local brightness and contrast differences between the two lenses */
    private fun normalize(g: FloatArray, w: Int, h: Int, tmp: FloatArray, ps: FloatArray): FloatArray {
        val n = w * h
        val mean = FloatArray(n)
        box(g, mean, tmp, ps, w, h, 6)
        val c = FloatArray(n) { g[it] - mean[it] }
        val sq = FloatArray(n) { c[it] * c[it] }
        val v = FloatArray(n)
        box(sq, v, tmp, ps, w, h, 6)
        return FloatArray(n) { c[it] / (sqrt(v[it]) + 0.02f) }
    }

    /** separable box blur with edge averaging */
    private fun box(src: FloatArray, dst: FloatArray, tmp: FloatArray, ps: FloatArray, w: Int, h: Int, r: Int) {
        for (y in 0 until h) {
            val o = y * w
            ps[0] = 0f
            for (x in 0 until w) ps[x + 1] = ps[x] + src[o + x]
            for (x in 0 until w) {
                val a = max(0, x - r); val b = min(w - 1, x + r)
                tmp[o + x] = (ps[b + 1] - ps[a]) / (b - a + 1)
            }
        }
        for (x in 0 until w) {
            ps[0] = 0f
            for (y in 0 until h) ps[y + 1] = ps[y] + tmp[y * w + x]
            for (y in 0 until h) {
                val a = max(0, y - r); val b = min(h - 1, y + r)
                dst[y * w + x] = (ps[b + 1] - ps[a]) / (b - a + 1)
            }
        }
    }
}

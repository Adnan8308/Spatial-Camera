package com.example.dualparallax

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import java.io.File

class GalleryActivity : Activity() {

    private lateinit var viewer: ParallaxView
    private lateinit var strip: LinearLayout
    private lateinit var info: TextView
    private var current: File? = null

    private val dir get() = File(getExternalFilesDir(null), "pairs")

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 11f
        isAllCaps = false
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }

        viewer = ParallaxView(this)
        root.addView(viewer, LinearLayout.LayoutParams(-1, 0, 1f))

        info = TextView(this).apply {
            setTextColor(Color.LTGRAY)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(16, 8, 16, 8)
            text = "Tilt the phone or drag a finger."
        }
        root.addView(info)

        root.addView(SeekBar(this).apply {
            max = 100
            progress = 50
            setPadding(48, 8, 48, 8)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    viewer.strength = p / 100f * 0.12f
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(btn("Auto") { viewer.auto = !viewer.auto })
        row1.addView(btn("Flip tilt") { viewer.invertTilt = !viewer.invertTilt })
        row1.addView(btn("Invert depth") { viewer.invertDepth = !viewer.invertDepth })
        root.addView(row1)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(btn("Show depth map") { viewer.showDepth = !viewer.showDepth })
        row2.addView(btn("Delete") { deleteCurrent() })
        root.addView(row2)

        strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(HorizontalScrollView(this).apply { addView(strip) }, LinearLayout.LayoutParams(-1, 220))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        strip.removeAllViews()
        val files = (dir.listFiles { f -> f.name.endsWith("_a.jpg") } ?: emptyArray())
            .sortedByDescending { it.name }
        if (files.isEmpty()) {
            info.text = "No photos yet. Capture one first."
            viewer.setImages(null, null)
            current = null
            return
        }
        for (f in files) {
            val iv = ImageView(this).apply {
                setPadding(6, 6, 6, 6)
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(decode(f, 6))
                setOnClickListener { select(f) }
            }
            strip.addView(iv, LinearLayout.LayoutParams(260, 208))
        }
        select(current?.takeIf { it.exists() } ?: files.first())
    }

    private fun select(a: File) {
        current = a
        val base = a.name.removeSuffix("_a.jpg")
        val color = decode(File(a.parentFile, base + "_b.jpg"), 1)
        val dFile = File(a.parentFile, base + "_d.png")
        val depth = if (dFile.exists()) decode(dFile, 1) else null
        if (color == null) return
        viewer.setImages(color, depth ?: Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.GRAY) })
        info.text = if (depth == null) "No depth map for this photo (old capture)."
        else "Tilt, drag, or tap Auto. If it looks inside-out, tap Invert depth."
    }

    private fun deleteCurrent() {
        val a = current ?: return
        val base = a.name.removeSuffix("_a.jpg")
        a.delete()
        File(a.parentFile, base + "_b.jpg").delete()
        File(a.parentFile, base + "_d.png").delete()
        current = null
        refresh()
    }

    private fun decode(f: File, sample: Int): Bitmap? =
        BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
}

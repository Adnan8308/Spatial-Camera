package com.example.dualparallax

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

class GalleryActivity : Activity() {

    private lateinit var viewer: ParallaxView
    private lateinit var strip: LinearLayout
    private lateinit var empty: TextView
    private var current: File? = null

    private val dir get() = File(getExternalFilesDir(null), "pairs")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }

        viewer = ParallaxView(this)
        root.addView(viewer, LinearLayout.LayoutParams(-1, 0, 1f))

        empty = TextView(this).apply {
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            text = "Tilt the phone or drag a finger to see the parallax."
            setPadding(16, 16, 16, 16)
        }
        root.addView(empty)

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        buttons.addView(Button(this).apply {
            text = "Auto wiggle"
            setOnClickListener { viewer.auto = !viewer.auto }
        })
        buttons.addView(Button(this).apply {
            text = "Flip tilt"
            setOnClickListener { viewer.invertTilt = !viewer.invertTilt }
        })
        buttons.addView(Button(this).apply {
            text = "Delete"
            setOnClickListener { deleteCurrent() }
        })
        root.addView(buttons)

        strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val scroll = HorizontalScrollView(this).apply { addView(strip) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 220))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        strip.removeAllViews()
        val files = (dir.listFiles { f -> f.name.endsWith("_a.jpg") } ?: emptyArray())
            .sortedByDescending { it.name }
        if (files.isEmpty()) {
            empty.text = "No photos yet. Capture one first."
            viewer.setImages(null, null)
            current = null
            return
        }
        for (f in files) {
            val iv = ImageView(this).apply {
                setPadding(6, 6, 6, 6)
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(decode(f, 6))
                setOnClickListener { select(f) }
            }
            strip.addView(iv, LinearLayout.LayoutParams(260, 208))
        }
        select(current?.takeIf { it.exists() } ?: files.first())
    }

    private fun select(a: File) {
        current = a
        val b = File(a.parentFile, a.name.replace("_a.jpg", "_b.jpg"))
        viewer.setImages(decode(a, 1), decode(b, 1))
        empty.text = "Tilt the phone or drag a finger. Tap Auto wiggle for a loop."
    }

    private fun deleteCurrent() {
        val a = current ?: return
        a.delete()
        File(a.parentFile, a.name.replace("_a.jpg", "_b.jpg")).delete()
        current = null
        refresh()
    }

    private fun decode(f: File, sample: Int): Bitmap? =
        BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
}

# Dual Parallax

Takes one photo with the S26 Ultra main camera (digital ~3x crop) and the 3x telephoto at the same time,
then blends the two slightly different viewpoints into a tilt-controlled parallax image.

## Build
1. Open this folder in Android Studio (Koala or newer). Let Gradle sync (it downloads Gradle 8.7 itself).
2. Enable Developer options + USB debugging on the phone, plug it in, press Run.
3. Allow the camera permission.

## Use
- Main screen shows the main camera zoomed ~3x. The top text lists every back camera the phone exposes.
- CAPTURE saves a pair. Gallery shows the pairs: tilt the phone, drag a finger, or tap "Auto wiggle".
- If the tilt feels backwards, tap "Flip tilt".

## If it says it cannot find the cameras
Samsung may not expose the physical lenses to third-party apps. Copy the camera list printed at the top
of the main screen and send it back so the code can be adapted.
